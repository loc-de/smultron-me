import Logo from "./components/Logo";

export default function App() {
  return (
      <div className="app">
        <div className="main">
          <div className="center">
            <Logo/>
            <p className="hint">smultron.</p>
          </div>
        </div>
      </div>
  );
}
